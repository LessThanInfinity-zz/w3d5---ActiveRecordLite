class MassObject
  def self.set_attrs(*attributes)
  end

  def self.attributes
  end

  def self.parse_all(results)
  end

  def initialize(params = {})
  end
end
